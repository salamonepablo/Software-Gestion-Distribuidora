import java.text.SimpleDateFormat;
import java.util.Date;

import feafip.ClassFactory;
import feafip.Iwsfev1;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
        //URLs de autenticacion y negocio. Cambiarlas por las de producci�n al implementarlas en el cliente(abajo)
        String URLWSAA = "https://wsaahomo.afip.gov.ar/ws/services/LoginCms";
          // Producci�n: https://wsaa.afip.gov.ar/ws/services/LoginCms
        String URLWSW = "https://wswhomo.afip.gov.ar/wsfev1/service.asmx";
          // Producci�n: https://servicios1.afip.gov.ar/wsfev1/service.asmx
        double nro;

        int ptoVta = 30;
        int tipoComp = 1; 
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        String FechaComp = formatter.format(new Date());
         
        Iwsfev1 wsfev1 = ClassFactory.createwsfev1();
        wsfev1.cuit(20939802593.0);  // Cuit del vendedor
        wsfev1.url(URLWSW);
        if (wsfev1.login("certificado.crt", "clave.key", URLWSAA)){
            if (!wsfev1.sfRecuperaLastCMP(ptoVta, tipoComp)) {
            	System.out.print(wsfev1.errorDesc());
            } else {
                nro = wsfev1.sfLastCMP() + 1;
                wsfev1.reset();
                wsfev1.agregaFactura(1, 80, 27929007862.0, nro, nro, FechaComp, 121, 0, 100, 0, "", "", "", "PES", 1);
                wsfev1.agregaIVA(5, 100, 21); // Ver Excel de referencias de codigos AFIP
                if (!wsfev1.autorizar(ptoVta, tipoComp)){
                	System.out.print(wsfev1.errorDesc());
                } else {
                    if (wsfev1.sfResultado(0).equals("A")) {
                    	System.out.print("Felicitaciones! Si ve este mensaje instalo correctamente FEAFIP. CAE y Vencimiento: "  + wsfev1.sfcae(0) + " " + wsfev1.sfVencimiento(0));
                    } else {
                    	System.out.print(wsfev1.autorizarRespuestaObs(0));
                    }
                }
            }
        } else {
        	System.out.print(wsfev1.errorDesc());
        }
		
	}

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public Main() {
		super();
	}

}