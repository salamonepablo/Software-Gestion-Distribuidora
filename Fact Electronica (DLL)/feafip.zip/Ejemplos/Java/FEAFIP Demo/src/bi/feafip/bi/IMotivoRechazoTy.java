package feafip  ;

import com4j.*;

@IID("{21AC85E6-B7A9-487F-BCBC-19E18AE05D42}")
public interface IMotivoRechazoTy extends Com4jObject {
  // Methods:
  // Properties:
}
