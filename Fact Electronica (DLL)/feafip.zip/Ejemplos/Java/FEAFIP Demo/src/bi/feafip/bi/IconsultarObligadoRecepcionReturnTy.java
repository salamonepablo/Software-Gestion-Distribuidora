package feafip  ;

import com4j.*;

@IID("{2C7111F1-8465-43EB-9110-9303B3961AC3}")
public interface IconsultarObligadoRecepcionReturnTy extends Com4jObject {
  // Methods:
  /**
   * <p>
   * Getter method for the COM property "respuesta"
   * </p>
   * @return  Returns a value of type boolean
   */

  @DISPID(201) //= 0xc9. The runtime will prefer the VTID if present
  @VTID(7)
  boolean respuesta();


  /**
   * <p>
   * Getter method for the COM property "desde"
   * </p>
   * @return  Returns a value of type java.lang.String
   */

  @DISPID(202) //= 0xca. The runtime will prefer the VTID if present
  @VTID(8)
  java.lang.String desde();


  // Properties:
}
