package feafip  ;

import com4j.*;

@IID("{96443A17-3274-4493-A940-92F4FE8F4D98}")
public interface IOtroTributoTy extends Com4jObject {
  // Methods:
  // Properties:
}
